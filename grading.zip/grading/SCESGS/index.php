<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
	<?php include('header.html');?>
	</br>
	<table width="25%" style="border: 4px solid #3c8653;border-style: inset;border-radius: 10px;background-color: #21b8cc;">
		<tr>
			<th width="80%">
				</br>
				<font style="font-size: 15px;"><a href="login.php?usertype=ADMIN" style="text-decoration: none;text-decoration: none;background-color: #6cf1de;border-style: outset;border: 2px solid gray;border-radius: 5px;padding: 10px 30px;color: black;">ADMIN</a></font>
				&nbsp;&nbsp;
				<font style="font-size: 15px;"><a href="login.php?usertype=USER" style="text-decoration: none;text-decoration: none;background-color: #6cf1de;border-style: outset;border: 2px solid gray;border-radius: 5px;padding: 10px 30px;color: black;">USER</a></font>
				</br></br>
			</th>
		</tr>
	</table>
</center>
</body>
</html>